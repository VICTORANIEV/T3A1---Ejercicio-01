/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package t3a1;

import java.util.Scanner;

/**
 *
 * @author VICTOR ANIEV
 */
public class T3A1 {

    
    public static void main(String[] args) {
        procesar();
    } 
    
    public static void procesar() {
        Scanner scanner = new Scanner(System.in);
        Promedio promedio = new Promedio();
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        promedio.setNombre(nombre);
        
        System.out.print("Apellido Paterno: ");
        String apellidoPaterno = scanner.nextLine();
        promedio.setApellidoPaterno(apellidoPaterno);
        
        System.out.print("Apellido Materno: ");
        String apellidoMaterno = scanner.nextLine();
        promedio.setApellidoMaterno(apellidoMaterno);
        
        System.out.println("Grupo: ");
        String grupo = scanner.nextLine();
        promedio.setGrupo(grupo);
        
        System.out.println("Carrera: ");
        String carrera = scanner.nextLine();
        promedio.setCarrera(carrera);
        
        System.out.println("Asignatura: ");
        String nombreAsignatura = scanner.nextLine();
        promedio.setNombreAsignatura(nombreAsignatura);
        
        System.out.println("Asignatura 2: ");
        String nombreAsignatura2 = scanner.nextLine();
        promedio.setNombreAsignatura2(nombreAsignatura2);
        
        System.out.println("Calificacion: ");
        int calificacion2 = scanner.nextInt();
        promedio.setCalificacion(calificacion2);
        
        System.out.println("Calificacion 2: ");
        int calificacion = scanner.nextInt();
        promedio.setCalificacion2(calificacion);
        
        promedio.setPromedio(calificacion);
        
        System.out.println("Estudiante: " + promedio.getNombre());
        System.out.println("Grupo: " + promedio.getGrupo());
        System.out.println("Carrera: " + promedio.getCarrera());
        System.out.println("Asignatura: " + promedio.getNombreAsignatura());
        System.out.println("Calificacion: " + promedio.getCalificacion());
        System.out.println("Asignatura2: " + promedio.getNombreAsignatura2());
        System.out.println("Calificacion2: " + promedio.getCalificacion2());
        System.out.println("Promedio: " + promedio.getPromedio());
        
    }
    
}
